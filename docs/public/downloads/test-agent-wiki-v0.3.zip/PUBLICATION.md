v0.3 转为技术学习. 历史版本的交付/发布说明仅表示当时状态. 演示使用合成数据, 验证范围见 demos/agent-lab/verification.json.
